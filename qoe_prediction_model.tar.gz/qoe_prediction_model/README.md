# QoE Prediction Model

This package contains a trained model for Quality of Experience (QoE) prediction based on network metrics.

## Deployment Instructions

### Prerequisites
- Python 3.8 or higher
- pip package manager

### Installation
1. Clone or extract this package to your Linux machine
2. Navigate to the project directory:
   ```
   cd qoe_prediction_model
   ```
3. Create a virtual environment (recommended):
   ```
   python3 -m venv venv
   source venv/bin/activate
   ```
4. Install the required dependencies:
   ```
   pip install -r requirements.txt
   ```

## Usage

### Standard Mode
For standard inference (one JSON file per 10-second timepoint):

```bash
python3 scripts/run_inference.py --inference_file ./data/inference_inputs/20250204123000.json \
    --data_folder ./data/mock_dataset --seq_length 5 \
    --model_file ./models/model_transformer.h5 \
    --scaler_file ./models/scaler.save
```

### Augmented Mode
For augmented inference (one JSON file per 5-second window with per-second sub-records):

```bash
python3 scripts/run_inference.py --inference_file ./data/inference_inputs/20250402122044.json \
    --data_folder ./data/augmented_dataset --seq_length 5 \
    --model_file ./models/model_transformer.h5 \
    --scaler_file ./models/scaler.save --augmented
```

See README_FULL.md for complete documentation.
